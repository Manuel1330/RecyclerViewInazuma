package com.example.recyclerinazuma

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_resto.*

class MainActivity2 : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resto)

        if (intent.extras != null){
            Dorsal.text = intent.getStringExtra("Dorsal")
            Glide.with(applicationContext).load(intent.getStringExtra("Espiritu Guerrero")).into(Espiritu)
        }
    }
}