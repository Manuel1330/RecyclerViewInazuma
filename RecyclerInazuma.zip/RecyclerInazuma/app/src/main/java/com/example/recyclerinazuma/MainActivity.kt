package com.example.recyclerinazuma

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity(), RecyclerAdapter.onJugadoresClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        RecyclerViewInazuma.layoutManager=LinearLayoutManager(this)
        conectarJson()
    }

    fun conectarJson(){  // conecta con una url y devuelve su contenido
        val url="http://iesayala.ddns.net/perezosoman/"
        val queue= Volley.newRequestQueue(this)
        val array = ArrayList<Jugadores>()
        val stringRequest= StringRequest(Request.Method.GET,url, Response.Listener { response ->
            //conectó correctamente
            val jsonArray= JSONArray(response)
            for (i in 0 until jsonArray.length()){
                val jsonObject= JSONObject(jsonArray.getString(i))
                val Nombre=jsonObject.getString("Nombre")
                val Apellido=jsonObject.getString("Apellido")
                val Dorsal=jsonObject.getString("Dorsal")
                val Imagen=jsonObject.getString("Imagen")
                val Espiritu=jsonObject.getString("Espiritu Guerrero")
                val jugador = Jugadores(Nombre, Apellido, Dorsal, Imagen, Espiritu)
                array.add(jugador)
                }
            RecyclerViewInazuma.adapter=RecyclerAdapter(this, array, this)

        },Response.ErrorListener {
            Toast.makeText(this,"Error", Toast.LENGTH_SHORT).show()   // se produjo un error
        })

        queue.add(stringRequest)
    }

    override fun onImageClick(Dorsal:String, Espiritu:String){

        var extras:Bundle = Bundle()

        extras.putString("Dorsal",Dorsal)
        extras.putString("Espiritu Guerrero",Espiritu)

        val intent = Intent(this,MainActivity2::class.java)
        intent.putExtras(extras)
        startActivity(intent)

    }

}