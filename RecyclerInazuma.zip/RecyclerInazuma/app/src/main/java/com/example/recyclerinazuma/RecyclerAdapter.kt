package com.example.recyclerinazuma

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.view.menu.ActionMenuItemView
import androidx.appcompat.view.menu.MenuView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_imagen.view.*
import kotlinx.android.synthetic.main.activity_resto.view.*


class RecyclerAdapter (val context: Context, val ListaJugadores : List<Jugadores>, private val itemClickListener:onJugadoresClickListener) : RecyclerView.Adapter<BaseViewHolder<*>>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseViewHolder<*> {
        //val v = LayoutInflater.from(parent.context).inflate(R.layout.activity_imagen, parent, false)
        //return ViewHolder(v)
        return JugadoresViewHolder(LayoutInflater.from(context).inflate(R.layout.activity_imagen,parent,false))
    }

    interface onJugadoresClickListener{
        fun onImageClick(dorsal:String, espiritu:String)
    }

    override fun onBindViewHolder(holder: BaseViewHolder<*>, position: Int) {
        if (holder is JugadoresViewHolder){
            holder.bind(ListaJugadores[position], position)
        }
    }

    override fun getItemCount(): Int {
        return ListaJugadores.size
    }

    inner class JugadoresViewHolder(itemView: View):BaseViewHolder<Jugadores>(itemView){
        override fun bind(item: Jugadores, position: Int) {
            itemView.Nombre.text=item.Nombre.toString()
            itemView.Apellido.text=item.Apellido.toString()
            Glide.with(context).load(item.Imagen).into(itemView.Imagen)

            itemView.setOnClickListener{
                itemClickListener.onImageClick(item.Dorsal,item.Espiritu)
            }

        }

    }
}