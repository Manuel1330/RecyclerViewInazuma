package com.example.recyclerinazuma

data class Jugadores(val Nombre:String, val Apellido:String, val Dorsal:String, val Imagen:String, val Espiritu:String)